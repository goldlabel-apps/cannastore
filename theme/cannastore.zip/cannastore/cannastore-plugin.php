<?php
/**
 * Replaces Newsup's Header with React App Plugin
 *
 * @package Listingslab
 */

echo '<style>';
echo '.cannastore-header {';

echo 'background: #57ac0b;';
echo 'min-height: 225px;';

echo '}';
echo '</style>';

echo '<div class="cannastore-header">';
echo '';
echo '</div>';
