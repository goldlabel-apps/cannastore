﻿=== Newsup ===
Contributors: Listingslab, Themeansar
Author: listingslab@gmail.com
Requires at least: WordPress 4.7
Tested up to: 5.5
Requires PHP: 5.6
Stable tag: 2.6.0
Version: 3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: 

== Description ==


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Upload [cannastore.zip](https://github.com/listingslab-software/cannastore/raw/develop/theme/cannastore.zip)
3. Click on the 'Activate' button to use your new theme right away.

== Copyright ==

Listingslab MIT

== Credits ==

Newsup WordPress Theme, Copyright (c) 2020, Themeansar
Newsup is distributed under the terms of the GNU GPLs

* CSS bootstrap.css
Code and documentation copyright 2011-2016 Twitter, Inc. Code released under the MIT license. Docs released under Creative Commons.

* JS bootstrap.js
Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
https://github.com/twbs/bootstrap/blob/master/LICENSE

* JS marquee.js
Author: Aamir Afridi
URL:  http://aamirafridi.com/jquery/jquery-marquee-plugin
License: MIT

* Bootstrap navwalker
* Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
https://github.com/twittem/wp-bootstrap-navwalker

== Font Awesome license ==
https://github.com/FortAwesome/Font-Awesome FontAwesome 4.7.0 Copyright 2012 Dave Gandy 
Font License: SIL OFL 1.1 Code License: MIT License http://fontawesome.io/license/

* Customizer Pro *
Author: Justin Tadlock
URL:  https://github.com/justintadlock/trt-customizer-pro
License: GPLv2 or later

PHP functions & Hooks:
double category, tabbed function, featured function, exclusive post function, https://wordpress.org/themes/newsphere/, http://afthemes.com/, (C) 2020 AF Themes, GPLv2

== Smartmenu ==
======================================
 * Owner : https://github.com/vadikom
 * Copyright (c) Vasil Dinkov, Vadikom Web Ltd. ( https://github.com/vadikom/smartmenus/blob/master/LICENSE-MIT)
 * Licensed under https://github.com/vadikom/smartmenus
 * https://github.com/vadikom/smartmenus/blob/master/src/addons/keyboard/jquery.smartmenus.keyboard.js

* Screenshot Banner Image - https://pxhere.com/en/photo/1446003
License: CC0 Public Domain

== Post Image ==
License: CC0 Public Domain
* https://stocksnap.io/photo/IFZYRGBZZS
* https://stocksnap.io/photo/K8NTTCGBZU
* https://stocksnap.io/photo/Y7INZWA6RO
* https://stocksnap.io/photo/ESIL8FMH4Z
* https://stocksnap.io/photo/5XUIDY1YT3
* https://stocksnap.io/photo/HRXTJCEXOW
* https://stocksnap.io/photo/PYJKVJ1ST1
* https://stocksnap.io/photo/BASDBS5VNN

== Bredcrumb Image ==
License: CC0 Public Domain
* https://pxhere.com/en/photo/1349574
* https://pxhere.com/en/photo/734344

== Changelog ==

= Version 2.6.1

Welcome to Cannastore