<?php

/**

 *
 * @link       https://listingslab.com/work/wordpress/plugins/cannastore
 * @since      1.0.0
 *
 * @package    cannastore
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
